"""
Vector Search — Neo4j Native Vector Indexes
============================================
Fully offline — no Vertex AI, no GCP auth, no internet required.

Embedding model: sentence-transformers all-mpnet-base-v2 (local, CPU)
  - 768-dim vectors (same as text-embedding-005 — Neo4j indexes unchanged)
  - Model downloaded once on first run (~420MB), then cached locally at
    C:\\Users\\<you>\\.cache\\huggingface\\hub\\
  - Install: pip install sentence-transformers

Storage: Neo4j native vector indexes (Neo4j 5.11+)
  - Embeddings stored as `embedding` property on graph nodes
  - Similarity search via db.index.vector.queryNodes() Cypher call
  - No Matching Engine, no gRPC, no proxy issues

Four Neo4j vector indexes (created by create_indexes()):
  table_embeddings     — on :Table nodes
  kpi_embeddings       — on :KPI nodes
  concept_embeddings   — on :BusinessConcept nodes
  example_embeddings   — on :QueryExample nodes
"""

import os
import json
import logging

from neo4j import GraphDatabase

log = logging.getLogger("agentic_sl.vs")

# Model name — override via env var if you want a different sentence-transformers model
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-mpnet-base-v2")

# Vector dimensionality — all-mpnet-base-v2 produces 768-dim vectors,
# matching the existing Neo4j index configuration
VECTOR_DIM = 768


# ─── Embeddings ───────────────────────────────────────────────────────────────

class Embeddings:
    """Local embeddings via sentence-transformers.

    Fully offline — no GCP auth, no API calls, no proxy issues.
    Model is downloaded once from HuggingFace on first instantiation,
    then cached locally. Subsequent starts load from cache instantly.

    Falls back to zero-vectors if sentence-transformers is not installed,
    which triggers the keyword fallback path in VectorSearch.
    """

    def __init__(self):
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(EMBEDDING_MODEL)
            log.info(f"Embeddings: {EMBEDDING_MODEL} loaded (local, offline).")
        except ImportError:
            log.warning(
                "sentence-transformers not installed. "
                "Run: pip install sentence-transformers  "
                "Falling back to keyword search until installed."
            )
            self.model = None
        except Exception as e:
            log.warning(f"Embeddings init failed: {e}. Using keyword fallback.")
            self.model = None

    def embed(self, texts: list[str], task: str = "RETRIEVAL_DOCUMENT") -> list[list[float]]:
        """Embed a list of texts. Returns list of 768-dim float vectors.

        The `task` parameter is accepted for API compatibility with the
        previous Vertex AI implementation but is ignored here —
        sentence-transformers uses the same model for both indexing and query.
        """
        if not self.model:
            return [[0.0] * VECTOR_DIM for _ in texts]
        vectors = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
        return [v.tolist() for v in vectors]

    def embed_query(self, text: str) -> list[float]:
        """Embed a single search query."""
        return self.embed([text])[0]


# ─── VectorSearch ─────────────────────────────────────────────────────────────

class VectorSearch:
    """Semantic search via Neo4j native vector indexes.

    Embeddings are stored as `embedding` properties on graph nodes.
    Search is a single Cypher call to db.index.vector.queryNodes().
    No Vertex AI Matching Engine endpoints required.

    Pass an existing KnowledgeGraph instance to share its Neo4j driver
    (avoids opening a second connection to the same instance).
    """

    # Maps index name -> node label (used by keyword fallback)
    INDEX_LABEL = {
        "table_embeddings":   "Table",
        "kpi_embeddings":     "KPI",
        "concept_embeddings": "BusinessConcept",
        "example_embeddings": "QueryExample",
    }

    def __init__(self, kg=None):
        """
        Args:
            kg: Optional KnowledgeGraph instance. If provided, its Neo4j
                driver is reused (recommended). If None, a new driver is
                opened using the same NEO4J_* env vars.
        """
        self.emb = Embeddings()
        self._owns_driver = kg is None
        if kg is not None:
            self.driver = kg.driver
        else:
            self.driver = GraphDatabase.driver(
                os.getenv("NEO4J_URI", "bolt://localhost:7687"),
                auth=(
                    os.getenv("NEO4J_USER", "neo4j"),
                    os.getenv("NEO4J_PASSWORD", "password"),
                ),
            )

    # ── Index creation ────────────────────────────────────────────────────────

    def create_indexes(self, kg) -> None:
        """Create Neo4j vector indexes and populate embeddings on all nodes.

        Replaces the old index_from_graph() + Vertex AI upsert flow.
        Call once at the end of semantic_layer_setup.py.

        Steps:
          1. Create one vector index per node type (IF NOT EXISTS — idempotent).
          2. Pull ontology from Neo4j via kg.get_full_ontology_text().
          3. Build the embedding doc string per node (same text as before).
          4. Call sentence-transformers (all-mpnet-base-v2, local) to generate vectors.
          5. SET n.embedding and n.emb_doc on each node.
        """
        self._create_vector_indexes()

        raw = kg.get_full_ontology_text()
        if not raw:
            log.warning("Empty ontology — nothing to embed.")
            return

        ont = json.loads(raw)
        causal_map = ont.get("causal_map", [])
        counts = {"tables": 0, "kpis": 0, "concepts": 0, "examples": 0}

        # ── Tables ────────────────────────────────────────────────────────────
        for fqn, info in ont.get("tables", {}).items():
            cols = ", ".join(c["name"] for c in info.get("columns", []))
            metrics = ", ".join(
                k["name"] for k in ont.get("kpis", [])
                if fqn in k.get("tables", [])
            )
            doc = (
                f"Table: {info.get('name', '')} ({fqn})\n"
                f"Desc: {info.get('description', '')}\n"
                f"Cols: {cols}"
            )
            if metrics:
                doc += f"\nMetrics: {metrics}"
            vec = self.emb.embed([doc])[0]
            self._set_node_embedding("Table", "fqn", fqn, vec, doc)
            counts["tables"] += 1

        # ── KPIs ──────────────────────────────────────────────────────────────
        for kpi in ont.get("kpis", []):
            doc = (
                f"KPI: {kpi['name']}\n"
                f"Expression: {kpi.get('expression', '')}\n"
                f"Description: {kpi.get('description', '')}\n"
                f"Tables: {', '.join(kpi.get('tables', []))}"
            )
            vec = self.emb.embed([doc])[0]
            self._set_node_embedding("KPI", "name", kpi["name"], vec, doc)
            counts["kpis"] += 1

        # ── Business Concepts ─────────────────────────────────────────────────
        for c in ont.get("business_concepts", []):
            cname = c["concept"]
            causes  = [e["source"] for e in causal_map if e["target"] == cname]
            effects = [e["target"] for e in causal_map if e["source"] == cname]
            causal = ""
            if causes:
                causal += f"\nCaused by: {', '.join(causes)}"
            if effects:
                causal += f"\nAffects: {', '.join(effects)}"
            doc = (
                f"Concept: {cname}\n"
                f"Description: {c.get('description', '')}\n"
                f"Synonyms: {', '.join(c.get('synonyms', []))}\n"
                f"Calculation: {c.get('calculation_hint', '')}"
                f"{causal}"
            )
            vec = self.emb.embed([doc])[0]
            self._set_node_embedding("BusinessConcept", "name", cname, vec, doc)
            counts["concepts"] += 1

        # ── Query Examples ────────────────────────────────────────────────────
        for ex in ont.get("example_queries", []):
            doc = (
                f"Q: {ex['question']}\n"
                f"SQL: {ex['sql']}\n"
                f"Complexity: {ex.get('complexity', 'simple')}"
            )
            vec = self.emb.embed([doc])[0]
            self._set_node_embedding(
                "QueryExample", "question", ex["question"], vec, doc
            )
            counts["examples"] += 1

        log.info(
            f"Embeddings stored on nodes — "
            f"tables: {counts['tables']}, kpis: {counts['kpis']}, "
            f"concepts: {counts['concepts']}, examples: {counts['examples']}"
        )

    def _create_vector_indexes(self) -> None:
        """Create the four Neo4j vector indexes (idempotent)."""
        index_defs = [
            ("table_embeddings",   "Table",           VECTOR_DIM),
            ("kpi_embeddings",     "KPI",             VECTOR_DIM),
            ("concept_embeddings", "BusinessConcept", VECTOR_DIM),
            ("example_embeddings", "QueryExample",    VECTOR_DIM),
        ]
        with self.driver.session() as s:
            for idx_name, label, dims in index_defs:
                try:
                    s.run(
                        f"CREATE VECTOR INDEX {idx_name} IF NOT EXISTS "
                        f"FOR (n:{label}) ON n.embedding "
                        f"OPTIONS {{indexConfig: {{"
                        f"  `vector.dimensions`: {dims},"
                        f"  `vector.similarity_function`: 'cosine'"
                        f"}}}}"
                    )
                    log.info(f"  Vector index ready: {idx_name} ({label})")
                except Exception as e:
                    log.warning(f"  Index {idx_name} creation warning: {e}")

    def _set_node_embedding(
        self,
        label: str,
        key_prop: str,
        key_val: str,
        vector: list[float],
        doc: str,
    ) -> None:
        """Write an embedding vector and its source doc string onto a node."""
        with self.driver.session() as s:
            s.run(
                f"MATCH (n:{label} {{{key_prop}: $v}}) "
                f"SET n.embedding = $emb, n.emb_doc = $doc",
                v=key_val, emb=vector, doc=doc,
            )

    # ── index_example: used by LearningAgent (currently disabled) ─────────────

    def index_example(self, question: str, sql: str, tables: list[str]) -> None:
        """Embed a new example and store it on the QueryExample node.

        The QueryExample node must already exist in Neo4j (created by
        kg.upsert_example). Called from semantic_layer_setup.py after
        kg.upsert_example() for each example.
        """
        doc = (
            f"Q: {question}\n"
            f"SQL: {sql}"
        )
        vec = self.emb.embed([doc])[0]
        self._set_node_embedding("QueryExample", "question", question, vec, doc)

    # ── Search ────────────────────────────────────────────────────────────────

    def search_tables(self, query: str, k: int = 5) -> list[dict]:
        rows = self._vector_search("table_embeddings", query, k)
        return [
            {
                "fqn":   r.get("fqn", ""),
                "name":  r.get("name", ""),
                "doc":   r.get("emb_doc", ""),
                "score": r.get("score", 0.0),
            }
            for r in rows
        ]

    def search_kpis(self, query: str, k: int = 5) -> list[dict]:
        rows = self._vector_search("kpi_embeddings", query, k)
        return [
            {
                "kpi_name": r.get("name", ""),
                "doc":      r.get("emb_doc", ""),
            }
            for r in rows
        ]

    def search_concepts(self, query: str, k: int = 5) -> list[dict]:
        rows = self._vector_search("concept_embeddings", query, k)
        return [
            {
                "concept": r.get("name", ""),
                "doc":     r.get("emb_doc", ""),
            }
            for r in rows
        ]

    def search_examples(self, query: str, k: int = 5) -> list[dict]:
        rows = self._vector_search("example_embeddings", query, k)
        return [
            {
                "nl_query":   r.get("question", ""),
                "sql":        r.get("sql", ""),
                "doc":        r.get("emb_doc", ""),
                "complexity": r.get("complexity", "simple"),
            }
            for r in rows
        ]

    # ── Internal ──────────────────────────────────────────────────────────────

    def _vector_search(self, index_name: str, query: str, k: int) -> list[dict]:
        """Run Neo4j vector similarity search.

        Falls back to keyword search if:
          - The embedding model is down (zero vectors returned).
          - The Neo4j vector query fails (index not yet populated, etc.).
        """
        query_vec = self.emb.embed_query(query)

        if all(v == 0.0 for v in query_vec):
            log.warning(f"Zero query vector — keyword fallback for: {query!r}")
            return self._keyword_fallback(index_name, query, k)

        try:
            with self.driver.session() as s:
                result = s.run(
                    "CALL db.index.vector.queryNodes($idx, $k, $vec) "
                    "YIELD node, score "
                    "RETURN properties(node) AS props, score "
                    "ORDER BY score DESC",
                    idx=index_name, k=k, vec=query_vec,
                )
                rows = []
                for r in result:
                    props = dict(r["props"])
                    props.pop("embedding", None)   # never return raw vectors
                    props["score"] = r["score"]
                    rows.append(props)
                return rows
        except Exception as e:
            log.warning(f"Neo4j vector search failed ({e}) — keyword fallback")
            return self._keyword_fallback(index_name, query, k)

    def _keyword_fallback(self, index_name: str, query: str, k: int) -> list[dict]:
        """Word-overlap fallback. Reads emb_doc directly from Neo4j nodes —
        no stale in-memory cache, always consistent with the graph.
        """
        label = self.INDEX_LABEL.get(index_name, "")
        if not label:
            return []

        qwords = set(query.lower().split())
        if not qwords:
            return []

        with self.driver.session() as s:
            rows = s.run(
                f"MATCH (n:{label}) WHERE n.emb_doc IS NOT NULL "
                f"RETURN properties(n) AS props"
            )
            candidates = []
            for r in rows:
                props = dict(r["props"])
                props.pop("embedding", None)
                doc_words = set((props.get("emb_doc", "") or "").lower().split())
                overlap   = len(qwords & doc_words)
                props["score"] = overlap / max(len(qwords), 1)
                candidates.append(props)

        candidates.sort(key=lambda x: x["score"], reverse=True)
        return candidates[:k]

    def close(self):
        if self._owns_driver:
            self.driver.close()