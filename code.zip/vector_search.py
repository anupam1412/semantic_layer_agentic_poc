"""
Vertex AI Vector Search — 4 Embedding Indexes (Fixed)
=====================================================
Fixes:
  - _fallback: inverted scoring logic corrected (more overlap = lower distance)
  - index_from_graph: handles empty ontology gracefully
  - Embeddings: fallback to zero vectors if Vertex AI unavailable
  - CRITICAL FIX: _meta now auto-populates from Neo4j on first search
    so keyword fallback works even when Vertex AI gRPC is unreachable
  - Deployed index IDs now configurable via env vars
"""

import os, json, hashlib, logging
import vertexai
from vertexai.language_models import TextEmbeddingModel, TextEmbeddingInput
from google.cloud import aiplatform

log = logging.getLogger("agentic_sl.vs")


class Embeddings:
    def __init__(self):
        try:
            vertexai.init(
                project=os.getenv("GCP_PROJECT", "acn-uki-ds-data-ai-project"),
                location=os.getenv("GCP_REGION", "europe-west2"),
            )
            self.model = TextEmbeddingModel.from_pretrained(
                os.getenv("EMBEDDING_MODEL", "text-embedding-005")
            )
        except Exception as e:
            log.warning(f"Embeddings init failed: {e}. Using zero-vector fallback.")
            self.model = None

    def embed(self, texts, task="RETRIEVAL_DOCUMENT"):
        if not self.model:
            return [[0.0] * 768 for _ in texts]
        inputs = [TextEmbeddingInput(text=t, task_type=task) for t in texts]
        out = []
        for i in range(0, len(inputs), 250):
            out.extend(
                [e.values for e in self.model.get_embeddings(inputs[i : i + 250])]
            )
        return out


class VectorSearch:
    def __init__(self):
        aiplatform.init(
            project=os.getenv("GCP_PROJECT", "acn-uki-ds-data-ai-project"),
            location=os.getenv("GCP_REGION", "europe-west2"),
        )
        self.emb = Embeddings()
        self.endpoint = None
        ep_id = os.getenv("VS_INDEX_ENDPOINT_ID", "")
        if ep_id:
            try:
                self.endpoint = aiplatform.MatchingEngineIndexEndpoint(ep_id)
            except Exception as e:
                log.warning(f"VS endpoint init failed: {e}")
        self._idx = {
            "tables": os.getenv("VS_TABLES_INDEX_ID", ""),
            "kpis": os.getenv("VS_KPIS_INDEX_ID", ""),
            "concepts": os.getenv("VS_CONCEPTS_INDEX_ID", ""),
            "examples": os.getenv("VS_EXAMPLES_INDEX_ID", ""),
        }
        # Deployed index IDs — configurable via env vars
        self._dep = {
            "tables": os.getenv("VS_TABLES_DEPLOYED_ID", "tables_deployed"),
            "kpis": os.getenv("VS_KPIS_DEPLOYED_ID", "kpis_deployed"),
            "concepts": os.getenv("VS_CONCEPTS_DEPLOYED_ID", "concepts_deployed"),
            "examples": os.getenv("VS_EXAMPLES_DEPLOYED_ID", "examples_deployed"),
        }
        self._meta: dict[str, dict] = {}
        self._meta_loaded = False

    def _ensure_meta_loaded(self):
        """Auto-populate _meta from Neo4j if it's empty.

        CRITICAL FIX: When adk web starts a new process, _meta is empty.
        The Vertex AI gRPC endpoint may be unreachable (wrong deployed IDs,
        network issues, etc.), so _fallback runs against an empty dict and
        returns 0 results for everything → NOT_ANSWERABLE for all queries.

        This method lazily loads the ontology from Neo4j into _meta on first
        search, so the keyword fallback always has data to search against.
        """
        if self._meta_loaded:
            return
        self._meta_loaded = True

        if self._meta:
            log.info(f"_meta already has {len(self._meta)} entries, skipping load.")
            return

        log.info("_meta is empty — auto-populating from Neo4j for keyword fallback...")
        try:
            # Import here to avoid circular imports at module level
            try:
                from .knowledge_graph import KnowledgeGraph
            except ImportError:
                from knowledge_graph import KnowledgeGraph

            kg = KnowledgeGraph()
            self.index_from_graph(kg)
            kg.close()
            log.info(f"Auto-populated _meta with {len(self._meta)} entries from Neo4j.")
        except Exception as e:
            log.error(f"Failed to auto-populate _meta from Neo4j: {e}")

    @staticmethod
    def _id(t):
        return hashlib.md5(t.encode()).hexdigest()

    def _upsert(self, coll, dps):
        idx = self._idx.get(coll)
        if idx:
            try:
                aiplatform.MatchingEngineIndex(idx).upsert_datapoints(
                    datapoints=[
                        aiplatform.compat.types.matching_engine_index.IndexDatapoint(
                            datapoint_id=d["id"], feature_vector=d["embedding"]
                        )
                        for d in dps
                    ]
                )
            except Exception as e:
                log.warning(f"Upsert {coll}: {e}")
        for d in dps:
            self._meta[d["id"]] = d["meta"]

    def _search(self, dep_id, query, k):
        if self.endpoint:
            try:
                emb = self.emb.embed([query], task="RETRIEVAL_QUERY")[0]
                resp = self.endpoint.find_neighbors(
                    deployed_index_id=dep_id, queries=[emb], num_neighbors=k
                )
                return [
                    {"distance": n.distance, **self._meta.get(n.id, {})}
                    for n in (resp[0] if resp and resp[0] else [])
                ]
            except Exception as e:
                log.warning(f"VS gRPC failed ({e}), using keyword fallback")
        return self._fallback(query, k)

    def _fallback(self, q, k):
        """Keyword-overlap fallback when Vector Search is unreachable.

        FIX: More keyword overlap now gives LOWER distance (better match).
        Previous version had this inverted.
        """
        qw = set(q.lower().split())
        if not qw:
            return list(self._meta.values())[:k]

        scored = []
        for meta in self._meta.values():
            doc_text = " ".join(str(v) for v in meta.values()).lower()
            doc_words = set(doc_text.split())
            overlap = len(qw & doc_words)
            # Higher overlap → lower distance (better match)
            distance = 1.0 - (overlap / max(len(qw), 1))
            scored.append((distance, meta))

        scored.sort(key=lambda x: x[0])
        return [{"distance": s[0], **s[1]} for s in scored[:k]]

    def index_from_graph(self, kg):
        """Pull all data from Neo4j and index into Vertex AI."""
        raw = kg.get_full_ontology_text()
        if not raw:
            log.warning("Empty ontology, nothing to index.")
            return

        ont = json.loads(raw)

        # Tables
        for fqn, info in ont.get("tables", {}).items():
            cols = ", ".join(c["name"] for c in info.get("columns", []))
            metrics = ""
            # Find KPIs computed from this table
            for kpi in ont.get("kpis", []):
                if fqn in kpi.get("tables", []):
                    metrics += f", {kpi['name']}"
            doc = (
                f"Table: {info.get('name', '')} ({fqn})\n"
                f"Desc: {info.get('description', '')}\n"
                f"Cols: {cols}"
            )
            if metrics:
                doc += f"\nMetrics: {metrics.lstrip(', ')}"
            emb = self.emb.embed([doc])[0]
            self._upsert(
                "tables",
                [{"id": self._id(fqn), "embedding": emb,
                  "meta": {"fqn": fqn, "name": info.get("name", ""), "doc": doc}}],
            )

        # KPIs
        for kpi in ont.get("kpis", []):
            doc = (
                f"KPI: {kpi['name']}\n"
                f"Expression: {kpi.get('expression', '')}\n"
                f"Description: {kpi.get('description', '')}\n"
                f"Tables: {', '.join(kpi.get('tables', []))}"
            )
            emb = self.emb.embed([doc])[0]
            self._upsert(
                "kpis",
                [{"id": self._id(kpi["name"]), "embedding": emb,
                  "meta": {"kpi_name": kpi["name"], "doc": doc}}],
            )

        # Concepts (with causal edges embedded in the doc)
        cm = ont.get("causal_map", [])
        for c in ont.get("business_concepts", []):
            cname = c["concept"]
            causes = [e["source"] for e in cm if e["target"] == cname]
            effects = [e["target"] for e in cm if e["source"] == cname]
            causal = ""
            if causes:
                causal += f"\nCaused by: {', '.join(causes)}"
            if effects:
                causal += f"\nAffects: {', '.join(effects)}"
            doc = (
                f"Concept: {cname}\n"
                f"Description: {c.get('description', '')}\n"
                f"Synonyms: {', '.join(c.get('synonyms', []))}\n"
                f"Calculation: {c.get('calculation_hint', '')}"
                f"{causal}"
            )
            emb = self.emb.embed([doc])[0]
            self._upsert(
                "concepts",
                [{"id": self._id(cname), "embedding": emb,
                  "meta": {"concept": cname, "doc": doc}}],
            )

        # Examples
        for ex in ont.get("example_queries", []):
            doc = (
                f"Q: {ex['question']}\n"
                f"SQL: {ex['sql']}\n"
                f"Complexity: {ex.get('complexity', 'simple')}"
            )
            emb = self.emb.embed([doc])[0]
            self._upsert(
                "examples",
                [{"id": self._id(ex["question"]), "embedding": emb,
                  "meta": {
                      "nl_query": ex["question"],
                      "sql": ex["sql"],
                      "doc": doc,
                      "complexity": ex.get("complexity", "simple"),
                  }}],
            )

        log.info(
            f"Indexed: {len(ont.get('tables', {}))} tables, "
            f"{len(ont.get('kpis', []))} KPIs, "
            f"{len(ont.get('business_concepts', []))} concepts, "
            f"{len(ont.get('example_queries', []))} examples"
        )

    def index_example(self, q, sql, tables):
        doc = f"Q: {q}\nSQL: {sql}"
        emb = self.emb.embed([doc])[0]
        self._upsert(
            "examples",
            [{"id": self._id(q), "embedding": emb,
              "meta": {"nl_query": q, "sql": sql, "doc": doc}}],
        )

    # ── Search methods ──

    def search_tables(self, q, k=5):
        self._ensure_meta_loaded()
        return [
            {
                "fqn": r.get("fqn", ""),
                "name": r.get("name", ""),
                "doc": r.get("doc", ""),
                "score": r.get("distance", 1),
            }
            for r in self._search(self._dep["tables"], q, k)
        ]

    def search_kpis(self, q, k=5):
        self._ensure_meta_loaded()
        return [
            {"kpi_name": r.get("kpi_name", ""), "doc": r.get("doc", "")}
            for r in self._search(self._dep["kpis"], q, k)
        ]

    def search_concepts(self, q, k=5):
        self._ensure_meta_loaded()
        return [
            {"concept": r.get("concept", ""), "doc": r.get("doc", "")}
            for r in self._search(self._dep["concepts"], q, k)
        ]

    def search_examples(self, q, k=5):
        self._ensure_meta_loaded()
        return [
            {
                "nl_query": r.get("nl_query", ""),
                "sql": r.get("sql", ""),
                "doc": r.get("doc", ""),
                "complexity": r.get("complexity", "simple"),
            }
            for r in self._search(self._dep["examples"], q, k)
        ]