"""
ADK Multi-Agent Semantic Layer — ULTRA Token-Optimized
=======================================================
Aggressive truncation to stay well under 131K token limit.
Target: <80K tokens per request.
"""

import os
import sys
import json
import logging
from typing import Optional
from datetime import date, datetime

from google.adk.agents import Agent, SequentialAgent

try:
    from .knowledge_graph import KnowledgeGraph
    from .vector_search import VectorSearch
    from .bq_executor import BQExecutor
except ImportError:
    from knowledge_graph import KnowledgeGraph
    from vector_search import VectorSearch
    from bq_executor import BQExecutor

# Configure logging to show in terminal
logging.basicConfig(
    level=logging.INFO, 
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr  # Force output to stderr which ADK doesn't capture
)
log = logging.getLogger("agentic_sl")

# Also create a dedicated cypher logger
cypher_log = logging.getLogger("CYPHER")
cypher_log.setLevel(logging.INFO)

MODEL = os.getenv("GENERATIVE_MODEL", "gemini-2.5-flash")


def _log_cypher(msg: str):
    """Log Cypher query to stderr so it shows in terminal."""
    print(msg, file=sys.stderr, flush=True)


# ═══════════════════════════════════════════════════════════════════════════
# ULTRA-AGGRESSIVE TRUNCATION HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _serialize_dates(obj):
    """Convert date/datetime to ISO strings."""
    if obj is None:
        return None
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _serialize_dates(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_serialize_dates(item) for item in obj]
    return obj


def _mini_table_context(table_context: dict) -> dict:
    """ULTRA: Only table names and column names (no descriptions)."""
    mini = {}
    for tbl, ctx in table_context.items():
        if isinstance(ctx, dict):
            cols = ctx.get("columns", [])
            # Just column names, no types or descriptions
            mini[tbl] = [c.get("name", c) if isinstance(c, dict) else str(c) for c in cols[:8]]
        else:
            mini[tbl] = str(ctx)[:100]
    return mini


def _mini_domain_context(domain_context: dict) -> dict:
    """ULTRA: Only 2 items per layer, minimal fields."""
    mini = {}
    for layer, items in domain_context.items():
        if isinstance(items, list) and items:
            # Take first 2, extract only key identifiers
            mini[layer] = []
            for item in items[:2]:
                if isinstance(item, dict):
                    # Only keep name/type/date fields
                    mini[layer].append({
                        k: str(v)[:50] for k, v in item.items() 
                        if k in ("name", "type", "date", "action", "impact", "segment")
                    })
                else:
                    mini[layer].append(str(item)[:50])
        elif isinstance(items, dict) and items:
            mini[layer] = {k: str(v)[:50] for k, v in list(items.items())[:2]}
    return mini


# ─── Lazy store singletons ───
_kg: Optional[KnowledgeGraph] = None
_vs: Optional[VectorSearch] = None
_bq: Optional[BQExecutor] = None

def _get_kg() -> KnowledgeGraph:
    global _kg
    if _kg is None:
        _kg = KnowledgeGraph()
    return _kg

def _get_vs() -> VectorSearch:
    global _vs
    if _vs is None:
        _vs = VectorSearch()
    return _vs

def _get_bq() -> BQExecutor:
    global _bq
    if _bq is None:
        _bq = BQExecutor()
    return _bq


# ═══════════════════════════════════════════════════════════════════════════
# TOOL FUNCTIONS — ULTRA-COMPACT RETURNS
# ═══════════════════════════════════════════════════════════════════════════


def assess_knowledge(question: str) -> dict:
    """ULTRA-COMPACT triage scan."""
    kg = _get_kg()
    vs = _get_vs()

    # Minimal vector search
    tables = vs.search_tables(question, k=4)
    kpis = vs.search_kpis(question, k=3)
    concepts = vs.search_concepts(question, k=3)
    examples = vs.search_examples(question, k=2)

    # Get FQNs
    fqns = [t["fqn"] for t in tables if t.get("fqn")][:4]
    
    # ULTRA: Only column names, no full context
    table_context_raw = kg.get_table_context(fqns) if fqns else {}
    table_cols = _mini_table_context(table_context_raw)
    
    # Joins: just the conditions
    joins_raw = kg.get_joins(fqns)[:5] if fqns else []
    joins = [j.get("condition", str(j))[:80] for j in joins_raw if isinstance(j, dict)]

    # Diagnostic check
    q_lower = question.lower()
    is_diagnostic = any(w in q_lower for w in ["why", "reason", "cause", "explain", "declining", "drop", "increase"])

    # Coverage scoring (simplified)
    coverage = min(0.25 * len(tables)/3 + 0.25 * len(kpis)/2 + 0.25 * len(concepts)/2 + 0.25, 1.0)
    status = "ANSWERABLE" if coverage >= 0.5 else "PARTIALLY_ANSWERABLE" if coverage >= 0.25 else "NOT_ANSWERABLE"

    log.info(f"Triage: {status} ({coverage:.0%}), {len(tables)} tables, diagnostic={is_diagnostic}")

    return _serialize_dates({
        "status": status,
        "coverage": round(coverage, 2),
        "is_diagnostic": is_diagnostic,
        "tables": [t["fqn"].split(".")[-1] for t in tables],  # Just table names
        "kpis": [k.get("kpi_name", "") for k in kpis],
        "concepts": [c.get("concept", "") for c in concepts],
        "examples": [e.get("sql", "")[:80] for e in examples],
        "columns": table_cols,
        "joins": joins,
    })


def get_kpi_driver_tree(kpi_name: str) -> dict:
    """ULTRA-COMPACT: Just driver names, max depth 2."""
    _log_cypher(f"\n[CYPHER] get_kpi_driver_tree('{kpi_name}')")
    _log_cypher(f"[CYPHER] MATCH (p:KPI {{name:'{kpi_name}'}})-[:DRIVEN_BY*1..2]->(c:KPI)")
    _log_cypher(f"[CYPHER] RETURN DISTINCT c.name AS name, c.description AS desc")
    
    tree = _get_kg().get_kpi_driver_tree(kpi_name)
    
    _log_cypher(f"[CYPHER] Result: {len(tree.get('drivers', []))} drivers found")
    
    def extract_names(node, depth=0):
        if depth > 1 or not node:
            return None
        name = node.get("name", str(node)) if isinstance(node, dict) else str(node)
        drivers = node.get("drivers", []) if isinstance(node, dict) else []
        children = [extract_names(d, depth+1) for d in drivers[:4]]
        children = [c for c in children if c]
        return {"n": name[:30], "d": children} if children else name[:30]
    
    return _serialize_dates({"kpi": kpi_name, "tree": extract_names(tree)})


def get_causal_chain(concept_name: str) -> dict:
    """ULTRA-COMPACT: Just names of causes and effects."""
    _log_cypher(f"\n[CYPHER] get_causal_chain('{concept_name}')")
    _log_cypher(f"[CYPHER] MATCH (c:BusinessConcept)-[:AFFECTS*1..3]->(t:BusinessConcept {{name:'{concept_name}'}})")
    _log_cypher(f"[CYPHER] RETURN DISTINCT c.name AS concept  -- (causes)")
    _log_cypher(f"[CYPHER] MATCH (s:BusinessConcept {{name:'{concept_name}'}})-[:AFFECTS*1..3]->(e:BusinessConcept)")
    _log_cypher(f"[CYPHER] RETURN DISTINCT e.name AS concept  -- (effects)")
    
    chain = _get_kg().get_causal_chain(concept_name)
    
    _log_cypher(f"[CYPHER] Result: {len(chain.get('caused_by', []))} causes, {len(chain.get('affects', []))} effects")
    
    def names_only(items):
        return [
            (i.get("concept", i.get("name", str(i))) if isinstance(i, dict) else str(i))[:40]
            for i in (items or [])[:4]
        ]
    
    return _serialize_dates({
        "concept": concept_name,
        "caused_by": names_only(chain.get("caused_by", [])),
        "affects": names_only(chain.get("affects", [])),
    })


def get_triggering_events(concept_name: str) -> dict:
    """ULTRA-COMPACT: Just event summaries."""
    _log_cypher(f"\n[CYPHER] get_triggering_events('{concept_name}')")
    _log_cypher(f"[CYPHER] MATCH (d)-[:TRIGGERS]->(c:BusinessConcept {{name:'{concept_name}'}})")
    _log_cypher(f"[CYPHER] RETURN d, labels(d) AS type")
    
    events = _get_kg().get_triggering_events(concept_name)
    
    event_count = len(events) if isinstance(events, list) else 0
    _log_cypher(f"[CYPHER] Result: {event_count} triggering events found")
    
    if isinstance(events, list):
        mini = []
        for e in events[:3]:
            if isinstance(e, dict):
                mini.append({k: str(v)[:40] for k, v in e.items() if k in ("type", "name", "date", "impact")})
            else:
                mini.append(str(e)[:50])
        return _serialize_dates({"concept": concept_name, "events": mini})
    
    return _serialize_dates({"concept": concept_name, "events": []})


def get_full_causal_path(target_concept: str) -> dict:
    """ULTRA-COMPACT: Summarized path."""
    _log_cypher(f"\n[CYPHER] get_full_causal_path('{target_concept}')")
    _log_cypher(f"[CYPHER] MATCH path = (d)-[:TRIGGERS]->(c:BusinessConcept)-[:AFFECTS*1..3]->(t:BusinessConcept {{name:'{target_concept}'}})")
    _log_cypher(f"[CYPHER] RETURN nodes(path), relationships(path)")
    
    path = _get_kg().get_full_causal_path(target_concept)
    
    _log_cypher(f"[CYPHER] Result: path with {len(path) if isinstance(path, dict) else 0} elements")
    
    if isinstance(path, dict):
        mini = {}
        for key, val in path.items():
            if isinstance(val, list):
                mini[key] = [str(v)[:40] if not isinstance(v, dict) else v.get("name", "")[:40] for v in val[:3]]
            else:
                mini[key] = str(val)[:50]
        return _serialize_dates(mini)
    
    return _serialize_dates({"target": target_concept, "path": str(path)[:200]})


def search_schema_for_subquestion(sub_question: str, target_tables = "", target_kpi: str = "") -> dict:
    """ULTRA-COMPACT schema lookup. target_tables can be string or list."""
    _log_cypher(f"\n[SCHEMA] search_schema_for_subquestion")
    _log_cypher(f"[SCHEMA] Question: {sub_question[:80]}")
    _log_cypher(f"[SCHEMA] Tables: {target_tables}")
    _log_cypher(f"[SCHEMA] KPI: {target_kpi}")
    
    kg = _get_kg()
    vs = _get_vs()

    # Handle target_tables as either list or comma-separated string
    if isinstance(target_tables, list):
        table_list = [str(t).strip() for t in target_tables if t]
    elif isinstance(target_tables, str) and target_tables:
        table_list = [t.strip() for t in target_tables.split(",") if t.strip()]
    else:
        table_list = []

    _log_cypher(f"[VECTOR] Searching tables for: {sub_question[:50]}")
    focused = vs.search_tables(sub_question, k=3)
    fqns = list(set(
        [t["fqn"] for t in focused if t.get("fqn")]
        + table_list
    ))[:4]
    
    _log_cypher(f"[CYPHER] MATCH (t:Table) WHERE t.fqn IN {fqns}")
    _log_cypher(f"[CYPHER] MATCH (t)-[:HAS_COLUMN]->(c:Column) RETURN t, c")
    
    context = kg.get_table_context(fqns) if fqns else {}
    cols = _mini_table_context(context)
    
    _log_cypher(f"[CYPHER] MATCH (t1:Table)-[r:JOINS]->(t2:Table) WHERE t1.fqn IN {fqns}")
    joins = kg.get_joins(fqns)[:4] if fqns else []
    join_strs = [j.get("condition", "")[:60] for j in joins if isinstance(j, dict)]

    kpi_expr = ""
    if target_kpi:
        _log_cypher(f"[CYPHER] MATCH (k:KPI {{name:'{target_kpi}'}}) RETURN k.expression")
        try:
            kpi = kg.get_kpi(target_kpi)
            kpi_expr = kpi.get("expression", "")[:150] if kpi else ""
        except:
            pass

    _log_cypher(f"[SCHEMA] Result: {len(cols)} tables, {len(join_strs)} joins")
    
    return _serialize_dates({
        "tables": list(cols.keys()),
        "columns": cols,
        "joins": join_strs,
        "kpi_expression": kpi_expr,
    })


def execute_bigquery_sql(sql: str) -> dict:
    """Execute SQL, truncate results."""
    _log_cypher(f"\n[BIGQUERY] Executing SQL:")
    _log_cypher(f"[BIGQUERY] {sql[:500]}")
    
    bq = _get_bq()
    ok, msg = bq.validate(sql)
    if not ok:
        _log_cypher(f"[BIGQUERY] Validation FAILED: {msg[:100]}")
        return {"error": msg[:200], "sql": sql[:200]}
    
    _log_cypher(f"[BIGQUERY] Validation OK, executing...")
    result = bq.execute(sql)
    
    # Aggressive truncation of results
    if isinstance(result, dict):
        if "rows" in result and len(result["rows"]) > 20:
            _log_cypher(f"[BIGQUERY] Truncating {len(result['rows'])} rows to 20")
            result["rows"] = result["rows"][:20]
            result["truncated"] = True
        if "data" in result and isinstance(result["data"], list) and len(result["data"]) > 20:
            _log_cypher(f"[BIGQUERY] Truncating {len(result['data'])} data rows to 20")
            result["data"] = result["data"][:20]
            result["truncated"] = True
    
    row_count = len(result.get("rows", result.get("data", []))) if isinstance(result, dict) else 0
    _log_cypher(f"[BIGQUERY] Result: {row_count} rows returned")
    
    return _serialize_dates(result)


def check_kpi_thresholds(kpi_name: str, actual_value: float) -> dict:
    """Check KPI thresholds."""
    kpi = _get_kg().get_kpi(kpi_name)
    if not kpi:
        return {"status": "unknown", "kpi": kpi_name}

    thresholds = kpi.get("thresholds", {})
    status = "unknown"

    for level in ["green", "amber", "red"]:
        cond = thresholds.get(level, "")
        if not cond:
            continue
        try:
            parts = cond.strip().split()
            if len(parts) == 2:
                op, val = parts[0], float(parts[1])
                if ((op == ">=" and actual_value >= val) or
                    (op == ">" and actual_value > val) or
                    (op == "<=" and actual_value <= val) or
                    (op == "<" and actual_value < val)):
                    status = level
                    break
        except:
            continue

    return {"kpi": kpi_name, "value": actual_value, "status": status}


def get_domain_context(question: str) -> dict:
    """ULTRA-COMPACT domain context."""
    ctx = _get_kg().get_domain_context_for_question(question)
    return _serialize_dates(_mini_domain_context(ctx))


# ═══════════════════════════════════════════════════════════════════════════
# AGENT DEFINITIONS — MINIMAL INSTRUCTIONS
# ═══════════════════════════════════════════════════════════════════════════


triage_agent = Agent(
    name="TriageAgent",
    model=MODEL,
    description="Assesses query answerability using assess_knowledge tool.",
    instruction="""You are the TriageAgent. Your ONLY job is to assess if the question can be answered.

YOUR ONLY TOOL: assess_knowledge(question)

STEPS:
1. Call assess_knowledge with the user's question
2. Return the result as-is

OUTPUT: Return the JSON from assess_knowledge directly. Do not modify it.

You have NO other tools. Do not try to call any other functions.""",
    tools=[assess_knowledge],
    output_key="triage_report",
)


planner_agent = Agent(
    name="PlannerAgent",
    model=MODEL,
    description="Creates investigation plan using causal graph traversal.",
    instruction="""You are the PlannerAgent. Your job is to create an investigation plan.

YOUR TOOLS (use ONLY these 4):
1. get_kpi_driver_tree(kpi_name)
2. get_causal_chain(concept_name)
3. get_triggering_events(concept_name)
4. get_full_causal_path(target_concept)

You have NO other tools. Do NOT call search_schema_for_subquestion, execute_bigquery_sql, or assess_knowledge.

INPUT: Read {triage_report}

TASK 1 - Classify the question:
LOOKUP, TREND, PERIOD_COMPARE, ENTITY_COMPARE, SEGMENT_COMPARE, ROOT_CAUSE, ANOMALY

TASK 2 - For ROOT_CAUSE or ANOMALY:
- Call get_kpi_driver_tree for each KPI in triage_report
- Call get_causal_chain for each concept in triage_report
- Call get_full_causal_path if user asks for "trace", "root cause", "chain of events"
- Call get_triggering_events if user asks about specific events

TASK 3 - Output JSON plan:
{"category": "ROOT_CAUSE", "sub_questions": [{"q": "...", "tables": [...], "kpi": "..."}]}

You output a PLAN only. Another agent executes SQL.""",
    tools=[get_kpi_driver_tree, get_causal_chain, get_triggering_events, get_full_causal_path],
    output_key="investigation_plan",
)


investigator_agent = Agent(
    name="InvestigatorAgent",
    model=MODEL,
    description="Executes SQL queries against BigQuery.",
    instruction="""You are the InvestigatorAgent. Your job is to execute SQL queries.

YOUR TOOLS (use ONLY these 4):
1. search_schema_for_subquestion(sub_question, target_tables, target_kpi)
2. execute_bigquery_sql(sql)
3. check_kpi_thresholds(kpi_name, actual_value)
4. get_domain_context(question)

You have NO other tools. Do NOT call get_full_causal_path, get_causal_chain, get_kpi_driver_tree, or assess_knowledge.

INPUT: Read {investigation_plan}

For EACH sub_question in the plan:

STEP 1: Call search_schema_for_subquestion to get column names
STEP 2: Write SQL using ONLY those columns
STEP 3: Call execute_bigquery_sql to run it

SQL RULES:
- Backtick table names: `project.dataset.table`
- Use SAFE_DIVIDE(a,b) for division
- WHERE status='completed' for revenue

OUTPUT: [{"q": "...", "sql": "...", "result": {...}}]""",
    tools=[search_schema_for_subquestion, execute_bigquery_sql, check_kpi_thresholds, get_domain_context],
    output_key="findings",
)


synthesis_agent = Agent(
    name="SynthesisAgent",
    model=MODEL,
    description="Writes final report.",
    instruction="""Read {findings}. Write concise report:
1. Summary (2 sentences with numbers)
2. Key findings (3 bullets max)
3. Recommendation (1 sentence)

Use ONLY data from findings. No invention.""",
    tools=[],
    output_key="final_report",
)


# ═══════════════════════════════════════════════════════════════════════════
# ROOT AGENT
# ═══════════════════════════════════════════════════════════════════════════

root_agent = SequentialAgent(
    name="SemanticLayerPipeline",
    description="Triage → Planner → Investigator → Synthesis",
    sub_agents=[triage_agent, planner_agent, investigator_agent, synthesis_agent],
)