"""
Semantic Layer Setup — Configuration-Driven (Use-Case Agnostic)
===============================================================
Reads all ontology, domain layers, and data from YAML/JSON config files
and populates Neo4j + Vector Search.

This replaces the hardcoded semantic_layer_setup.py with a configuration-driven
approach. Same destination (full Neo4j), different source (config files).

Usage:
    # Load retail domain (default)
    python semantic_layer_setup_configurable.py
    
    # Load different domain
    python semantic_layer_setup_configurable.py --config-dir configs/healthcare
    
    # Dry run (validate configs without writing)
    python semantic_layer_setup_configurable.py --dry-run

Config Structure:
    configs/retail/
    ├── ontology.yaml         # Tables, KPIs, concepts, examples
    ├── domain_layers.yaml    # Event type schemas  
    ├── domain_data.yaml      # Actual domain events (10 layers)
    └── org_hierarchy.yaml    # Regions, stores, territories (optional)
"""

import os
import sys
import json
import logging
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional

import yaml

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
log = logging.getLogger("setup")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class ConfigurableSemanticLayerSetup:
    """Configuration-driven semantic layer setup for Neo4j."""
    
    def __init__(self, config_dir: str, dry_run: bool = False):
        self.config_dir = Path(config_dir)
        self.dry_run = dry_run
        
        # Config data
        self.ontology: Dict = {}
        self.domain_layers: Dict = {}
        self.domain_data: Dict = {}
        self.org_hierarchy: Dict = {}
        
        # Variable substitution map
        self.variables: Dict[str, str] = {}
        
        # Stats
        self.stats = {
            "tables": 0, "joins": 0, "fks": 0,
            "kpis": 0, "driver_edges": 0,
            "concepts": 0, "affects_edges": 0,
            "examples": 0,
            "regions": 0, "stores": 0, "territories": 0,
            "suppliers": 0, "supply_incidents": 0,
            "account_managers": 0, "contracts": 0, "churn_risks": 0,
            "competitor_actions": 0, "market_conditions": 0, "policy_changes": 0,
            "loyalty_tiers": 0, "redemption_rules": 0, "campaigns": 0,
            "pricing_decisions": 0, "discount_policies": 0,
            "categories": 0, "brands": 0,
        }
        
        # Lazy-loaded stores
        self._kg = None
        self._vs = None
        self._bq = None
    
    @property
    def kg(self):
        if self._kg is None and not self.dry_run:
            from knowledge_graph import KnowledgeGraph
            self._kg = KnowledgeGraph()
        return self._kg
    
    @property
    def vs(self):
        if self._vs is None and not self.dry_run:
            from vector_search import VectorSearch
            # Pass Neo4j driver to vector search (uses Neo4j native vector indexes)
            self._vs = VectorSearch(neo4j_driver=self.kg.driver)
        return self._vs
    
    @property
    def bq(self):
        if self._bq is None and not self.dry_run:
            from google.cloud import bigquery
            project = self.variables.get("bigquery_project", "")
            self._bq = bigquery.Client(project=project, location="europe-west2")
        return self._bq
    
    # ═══════════════════════════════════════════════════════════════════════
    # CONFIG LOADING
    # ═══════════════════════════════════════════════════════════════════════
    
    def _resolve_variables(self, text: str) -> str:
        """Replace ${var} placeholders with actual values."""
        import re
        def replacer(match):
            var_name = match.group(1)
            return self.variables.get(var_name, match.group(0))
        return re.sub(r'\$\{(\w+)\}', replacer, str(text))
    
    def _resolve_dict(self, d: Any) -> Any:
        """Recursively resolve variables in a dict/list structure."""
        if isinstance(d, dict):
            return {k: self._resolve_dict(v) for k, v in d.items()}
        elif isinstance(d, list):
            return [self._resolve_dict(item) for item in d]
        elif isinstance(d, str):
            return self._resolve_variables(d)
        return d
    
    def load_configs(self):
        """Load all config files from config_dir."""
        log.info(f"Loading configs from {self.config_dir}")
        
        # Load ontology (required)
        ontology_path = self.config_dir / "ontology.yaml"
        if not ontology_path.exists():
            raise FileNotFoundError(f"Required file not found: {ontology_path}")
        
        with open(ontology_path, 'r', encoding='utf-8') as f:
            raw_ontology = yaml.safe_load(f)
        
        # Extract variables from meta section
        meta = raw_ontology.get("meta", {})
        self.variables = {
            "bigquery_project": meta.get("bigquery_project", ""),
            "bigquery_dataset": meta.get("bigquery_dataset", ""),
            "P": f"{meta.get('bigquery_project', '')}.{meta.get('bigquery_dataset', '')}",
        }
        
        # Resolve variables and store
        self.ontology = self._resolve_dict(raw_ontology)
        log.info(f"  Loaded ontology: {len(self.ontology.get('tables', []))} tables, "
                f"{len(self.ontology.get('kpis', []))} KPIs, "
                f"{len(self.ontology.get('concepts', []))} concepts")
        
        # Load domain layers schema (optional)
        domain_layers_path = self.config_dir / "domain_layers.yaml"
        if domain_layers_path.exists():
            with open(domain_layers_path, 'r', encoding='utf-8') as f:
                self.domain_layers = yaml.safe_load(f)
            log.info(f"  Loaded domain layers: {len(self.domain_layers.get('layers', []))} layer types")
        
        # Load domain data (optional)
        domain_data_path = self.config_dir / "domain_data.yaml"
        if domain_data_path.exists():
            with open(domain_data_path, 'r', encoding='utf-8') as f:
                self.domain_data = self._resolve_dict(yaml.safe_load(f))
            log.info(f"  Loaded domain data: {sum(len(v) for k, v in self.domain_data.items() if isinstance(v, list))} events")
        
        # Load org hierarchy (optional)
        org_path = self.config_dir / "org_hierarchy.yaml"
        if org_path.exists():
            with open(org_path, 'r', encoding='utf-8') as f:
                self.org_hierarchy = self._resolve_dict(yaml.safe_load(f))
            log.info(f"  Loaded org hierarchy: {len(self.org_hierarchy.get('regions', []))} regions, "
                    f"{len(self.org_hierarchy.get('stores', []))} stores")
        
        return self
    
    # ═══════════════════════════════════════════════════════════════════════
    # LAYER 1: SCHEMA (Tables, Joins, FKs)
    # ═══════════════════════════════════════════════════════════════════════
    
    def setup_layer1_schema(self):
        """Populate tables, relationships, and foreign keys."""
        log.info("Layer 1: Schema...")
        
        tables = self.ontology.get("tables", [])
        dataset = self.variables.get("bigquery_dataset", "")
        
        # Option A: Auto-discover from BigQuery if tables list is empty or has "auto_discover: true"
        if self.ontology.get("meta", {}).get("auto_discover_schema", False):
            self._auto_discover_schema()
        else:
            # Option B: Use tables from config
            for table in tables:
                if self.dry_run:
                    log.info(f"  [DRY RUN] Would create table: {table['name']}")
                else:
                    self.kg.upsert_table(
                        fqn=table["fqn"],
                        name=table["name"],
                        desc=table.get("description", ""),
                        dataset=dataset,
                        columns=table.get("columns", []),
                    )
                self.stats["tables"] += 1
        
        # Relationships
        joins = self.ontology.get("joins", [])
        for join in joins:
            from_fqn = self._resolve_table_fqn(join["from"])
            to_fqn = self._resolve_table_fqn(join["to"])
            if from_fqn and to_fqn:
                if not self.dry_run:
                    self.kg.upsert_relationship(
                        from_fqn, to_fqn,
                        join.get("type", "ONE_TO_MANY"),
                        join.get("condition", ""),
                    )
                self.stats["joins"] += 1
        
        # Foreign keys
        fks = self.ontology.get("foreign_keys", [])
        for fk in fks:
            if not self.dry_run:
                self.kg.upsert_fk(fk["from"], fk["to"])
            self.stats["fks"] += 1
        
        log.info(f"  Layer 1 complete: {self.stats['tables']} tables, "
                f"{self.stats['joins']} joins, {self.stats['fks']} FKs")
    
    def _auto_discover_schema(self):
        """Auto-discover tables from BigQuery."""
        if self.dry_run:
            log.info("  [DRY RUN] Would auto-discover tables from BigQuery")
            return
        
        project = self.variables.get("bigquery_project", "")
        dataset = self.variables.get("bigquery_dataset", "")
        P = f"{project}.{dataset}"
        
        for tref in self.bq.list_tables(self.bq.dataset(dataset, project=project)):
            t = self.bq.get_table(tref)
            cols = [
                {"name": f.name, "type": f.field_type, "description": f.description or ""}
                for f in t.schema
            ]
            self.kg.upsert_table(f"{P}.{t.table_id}", t.table_id, t.description or "", dataset, cols)
            self.stats["tables"] += 1
            log.info(f"    Auto-discovered: {t.table_id} ({len(cols)} columns)")
    
    def _resolve_table_fqn(self, name_or_fqn: str) -> Optional[str]:
        """Resolve a table name to its FQN."""
        # If it already looks like an FQN (has dots), return as-is
        if "." in name_or_fqn:
            return name_or_fqn
        
        # Otherwise, look up in tables list
        for table in self.ontology.get("tables", []):
            if table["name"] == name_or_fqn:
                return table["fqn"]
        
        # Fall back to constructing FQN
        P = self.variables.get("P", "")
        return f"{P}.{name_or_fqn}" if P else name_or_fqn
    
    # ═══════════════════════════════════════════════════════════════════════
    # LAYER 2: ORG HIERARCHY
    # ═══════════════════════════════════════════════════════════════════════
    
    def setup_layer2_org_hierarchy(self):
        """Populate regions, stores, territories."""
        log.info("Layer 2: Org hierarchy...")
        
        if not self.org_hierarchy:
            log.info("  No org_hierarchy.yaml found, skipping")
            return
        
        # Regions
        for region in self.org_hierarchy.get("regions", []):
            if not self.dry_run:
                self.kg.upsert_region(
                    region["name"],
                    region.get("country", "GB"),
                    region.get("head", ""),
                    region.get("store_count", 0),
                )
            self.stats["regions"] += 1
        
        # Stores
        for store in self.org_hierarchy.get("stores", []):
            if not self.dry_run:
                self.kg.upsert_store_node(
                    store["store_id"],
                    store["name"],
                    store["region"],
                    store.get("type", "standard"),
                    store.get("capacity", 0),
                    store.get("opened", ""),
                    store.get("manager_name", ""),
                    store.get("manager_since", ""),
                    store.get("manager_experience", 0),
                )
            self.stats["stores"] += 1
        
        # Territories
        for territory in self.org_hierarchy.get("territories", []):
            if not self.dry_run:
                self.kg.upsert_territory(
                    territory["name"],
                    territory["region"],
                    territory.get("annual_target", 0),
                )
            self.stats["territories"] += 1
        
        log.info(f"  Layer 2 complete: {self.stats['regions']} regions, "
                f"{self.stats['stores']} stores, {self.stats['territories']} territories")
    
    # ═══════════════════════════════════════════════════════════════════════
    # LAYER 3: KPIs + DRIVER TREES
    # ═══════════════════════════════════════════════════════════════════════
    
    def setup_layer3_kpis(self):
        """Populate KPIs and driver tree edges."""
        log.info("Layer 3: KPIs + driver trees...")
        
        kpis = self.ontology.get("kpis", [])
        for kpi in kpis:
            # Resolve table names to FQNs
            table_fqns = [self._resolve_table_fqn(t) for t in kpi.get("tables", [])]
            table_fqns = [f for f in table_fqns if f]
            
            if not self.dry_run:
                self.kg.upsert_kpi(
                    name=kpi["name"],
                    expression=kpi.get("expression", ""),
                    table_fqns=table_fqns,
                    description=kpi.get("description", ""),
                    grain=kpi.get("grain", "monthly"),
                    thresholds=kpi.get("thresholds"),
                    dimensions=kpi.get("dimensions"),
                )
            self.stats["kpis"] += 1
        
        # Driver tree edges
        driver_edges = self.ontology.get("kpi_driver_tree", [])
        for edge in driver_edges:
            if not self.dry_run:
                self.kg.upsert_kpi_driver(edge["parent"], edge["child"])
            self.stats["driver_edges"] += 1
        
        log.info(f"  Layer 3 complete: {self.stats['kpis']} KPIs, "
                f"{self.stats['driver_edges']} driver edges")
    
    # ═══════════════════════════════════════════════════════════════════════
    # LAYER 4: CAUSAL REASONING (Concepts + AFFECTS)
    # ═══════════════════════════════════════════════════════════════════════
    
    def setup_layer4_causal(self):
        """Populate business concepts and AFFECTS edges."""
        log.info("Layer 4: Causal reasoning...")
        
        concepts = self.ontology.get("concepts", [])
        for concept in concepts:
            # Resolve table names to FQNs
            table_fqns = [self._resolve_table_fqn(t) for t in concept.get("maps_to_tables", [])]
            table_fqns = [f for f in table_fqns if f]
            
            if not self.dry_run:
                self.kg.upsert_concept(
                    concept=concept["name"],
                    description=concept.get("description", ""),
                    maps_to_tables=table_fqns,
                    maps_to_kpis=concept.get("maps_to_kpis"),
                    synonyms=concept.get("synonyms"),
                    calculation_hint=concept.get("calculation_hint", ""),
                )
            self.stats["concepts"] += 1
        
        # AFFECTS edges
        affects_edges = self.ontology.get("affects_edges", [])
        for edge in affects_edges:
            if not self.dry_run:
                self.kg.upsert_affects(
                    edge["from"],
                    edge["to"],
                    edge.get("mechanism", ""),
                )
            self.stats["affects_edges"] += 1
        
        log.info(f"  Layer 4 complete: {self.stats['concepts']} concepts, "
                f"{self.stats['affects_edges']} AFFECTS edges")
    
    # ═══════════════════════════════════════════════════════════════════════
    # LAYER 5: PRODUCT TAXONOMY
    # ═══════════════════════════════════════════════════════════════════════
    
    def setup_layer5_taxonomy(self):
        """Populate categories, subcategories, brands."""
        log.info("Layer 5: Product taxonomy...")
        
        taxonomy = self.ontology.get("taxonomy", {})
        
        # Categories
        for category in taxonomy.get("categories", []):
            if not self.dry_run:
                self.kg.upsert_category(category["name"])
                self.stats["categories"] += 1
                
                # Subcategories
                for sub in category.get("subcategories", []):
                    self.kg.upsert_category(sub, parent_category=category["name"])
                    self.stats["categories"] += 1
                
                # Brands for this category
                for brand in category.get("brands", []):
                    self.kg.upsert_brand(
                        brand["name"],
                        category["name"],
                        brand.get("tier", "mid"),
                    )
                    self.stats["brands"] += 1
        
        # Competes-with relationships
        for comp in taxonomy.get("competes_with", []):
            if not self.dry_run:
                self.kg.upsert_competes_with(comp["a"], comp["b"])
        
        log.info(f"  Layer 5 complete: {self.stats['categories']} categories, "
                f"{self.stats['brands']} brands")
    
    # ═══════════════════════════════════════════════════════════════════════
    # LAYERS 6-10: DOMAIN DATA
    # ═══════════════════════════════════════════════════════════════════════
    
    def setup_domain_layers(self):
        """Populate all domain event layers from domain_data.yaml."""
        if not self.domain_data:
            log.info("No domain_data.yaml found, skipping layers 6-10")
            return
        
        # Layer 6: Supply Chain
        self._setup_supply_chain()
        
        # Layer 7: Customer Relationships
        self._setup_customer_relationships()
        
        # Layer 8: Temporal Context
        self._setup_temporal_context()
        
        # Layer 9: Business Rules
        self._setup_business_rules()
        
        # Layer 10: Loyalty Program
        self._setup_loyalty_program()
    
    def _setup_supply_chain(self):
        """Layer 6: Suppliers and supply incidents."""
        log.info("Layer 6: Supply chain...")
        
        for supplier in self.domain_data.get("suppliers", []):
            if not self.dry_run:
                self.kg.upsert_supplier(
                    supplier["name"],
                    supplier.get("location", ""),
                    supplier.get("lead_time_weeks", 4),
                    supplier.get("supplies_brands", []),
                )
            self.stats["suppliers"] += 1
        
        for incident in self.domain_data.get("supply_incidents", []):
            if not self.dry_run:
                self.kg.upsert_supply_incident(
                    incident["supplier"],
                    incident["incident_type"],
                    incident["date"],
                    incident.get("description", ""),
                    incident.get("duration_weeks", 0),
                )
            self.stats["supply_incidents"] += 1
        
        for alt in self.domain_data.get("alternate_suppliers", []):
            if not self.dry_run:
                self.kg.upsert_alternate_supplier(alt["primary"], alt["alternate"])
        
        log.info(f"  Layer 6 complete: {self.stats['suppliers']} suppliers, "
                f"{self.stats['supply_incidents']} incidents")
    
    def _setup_customer_relationships(self):
        """Layer 7: Account managers, contracts, churn risks."""
        log.info("Layer 7: Customer relationships...")
        
        for am in self.domain_data.get("account_managers", []):
            if not self.dry_run:
                self.kg.upsert_account_manager(
                    am["name"],
                    am.get("segment", ""),
                    am.get("left_date"),
                    am.get("accounts", 0),
                )
            self.stats["account_managers"] += 1
        
        for contract in self.domain_data.get("contracts", []):
            if not self.dry_run:
                self.kg.upsert_contract(
                    contract["segment"],
                    contract.get("type", "standard"),
                    contract.get("tier", ""),
                    contract.get("expiry", ""),
                )
            self.stats["contracts"] += 1
        
        for risk in self.domain_data.get("churn_risks", []):
            if not self.dry_run:
                self.kg.upsert_churn_risk(
                    risk["segment"],
                    risk["risk_score"],
                    risk.get("reason", ""),
                )
            self.stats["churn_risks"] += 1
        
        log.info(f"  Layer 7 complete: {self.stats['account_managers']} managers, "
                f"{self.stats['contracts']} contracts, {self.stats['churn_risks']} risks")
    
    def _setup_temporal_context(self):
        """Layer 8: Competitor actions, market conditions, policy changes."""
        log.info("Layer 8: Temporal context...")
        
        for action in self.domain_data.get("competitor_actions", []):
            if not self.dry_run:
                self.kg.upsert_competitor_action(
                    action["competitor"],
                    action["action_type"],
                    action["date"],
                    action.get("description", ""),
                    action.get("impact", ""),
                    action.get("region"),
                )
            self.stats["competitor_actions"] += 1
        
        for condition in self.domain_data.get("market_conditions", []):
            if not self.dry_run:
                self.kg.upsert_market_condition(
                    condition["name"],
                    condition.get("description", ""),
                    condition["date"],
                    condition.get("severity", "moderate"),
                )
            self.stats["market_conditions"] += 1
        
        for policy in self.domain_data.get("policy_changes", []):
            if not self.dry_run:
                self.kg.upsert_policy_change(
                    policy["name"],
                    policy.get("description", ""),
                    policy["date"],
                    policy.get("location"),
                    policy.get("impact", ""),
                )
            self.stats["policy_changes"] += 1
        
        log.info(f"  Layer 8 complete: {self.stats['competitor_actions']} competitor actions, "
                f"{self.stats['market_conditions']} conditions, {self.stats['policy_changes']} policies")
    
    def _setup_business_rules(self):
        """Layer 9: Discount policies, pricing decisions, segment rules."""
        log.info("Layer 9: Business rules...")
        
        for policy in self.domain_data.get("discount_policies", []):
            if not self.dry_run:
                self.kg.upsert_discount_policy(
                    policy["category"],
                    policy.get("max_pct", 25),
                    policy.get("store_type"),
                    policy.get("approved_by", ""),
                )
            self.stats["discount_policies"] += 1
        
        for decision in self.domain_data.get("pricing_decisions", []):
            if not self.dry_run:
                self.kg.upsert_pricing_decision(
                    decision["category"],
                    decision["action"],
                    decision.get("reason", ""),
                    decision["date"],
                    decision.get("scope", "all"),
                )
            self.stats["pricing_decisions"] += 1
        
        for rule in self.domain_data.get("segment_rules", []):
            if not self.dry_run:
                self.kg.upsert_segment_rule(
                    rule["segment"],
                    rule["metric"],
                    rule["condition"],
                    rule.get("description", ""),
                )
        
        log.info(f"  Layer 9 complete: {self.stats['discount_policies']} discount policies, "
                f"{self.stats['pricing_decisions']} pricing decisions")
    
    def _setup_loyalty_program(self):
        """Layer 10: Loyalty tiers, redemption rules, campaigns."""
        log.info("Layer 10: Loyalty program...")
        
        for tier in self.domain_data.get("loyalty_tiers", []):
            if not self.dry_run:
                self.kg.upsert_loyalty_tier(
                    tier["name"],
                    tier.get("min_annual_spend", 0),
                    tier.get("points_multiplier", 1.0),
                )
            self.stats["loyalty_tiers"] += 1
        
        # Redemption rules - matches: upsert_redemption_rule(tier, points_per_gbp, effective_date, previous_ratio=None)
        for rule in self.domain_data.get("redemption_rules", []):
            if not self.dry_run:
                # Convert rule format to match knowledge_graph.py signature
                # The YAML has: name, rule_type, old_value, new_value, effective_date
                # The method expects: tier, points_per_gbp, effective_date, previous_ratio
                # We need to adapt - use a sensible default or skip if format doesn't match
                tier = rule.get("tier", "gold")  # Default tier
                points_per_gbp = rule.get("points_per_gbp", 100)
                effective_date = rule["effective_date"]
                previous_ratio = rule.get("previous_ratio", rule.get("old_value"))
                
                self.kg.upsert_redemption_rule(
                    tier,
                    points_per_gbp,
                    effective_date,
                    previous_ratio,
                )
            self.stats["redemption_rules"] += 1
        
        # Loyalty campaigns - matches: upsert_loyalty_campaign(name, target_tier, campaign_type, sent_date, description="")
        for campaign in self.domain_data.get("loyalty_campaigns", []):
            if not self.dry_run:
                # The method expects a single target_tier, but YAML has target_tiers list
                # Create one campaign entry per target tier
                target_tiers = campaign.get("target_tiers", ["gold"])
                for target_tier in target_tiers:
                    self.kg.upsert_loyalty_campaign(
                        campaign["name"],
                        target_tier,
                        campaign["campaign_type"],
                        campaign["start_date"],  # Use start_date as sent_date
                        campaign.get("description", ""),
                    )
            self.stats["campaigns"] += 1
        
        log.info(f"  Layer 10 complete: {self.stats['loyalty_tiers']} tiers, "
                f"{self.stats['redemption_rules']} rules, {self.stats['campaigns']} campaigns")
    
    # ═══════════════════════════════════════════════════════════════════════
    # EXAMPLES + VECTOR SEARCH INDEXING
    # ═══════════════════════════════════════════════════════════════════════
    
    def setup_examples(self):
        """Populate few-shot SQL examples."""
        log.info("Setting up examples...")
        
        examples = self.ontology.get("examples", [])
        for ex in examples:
            table_fqns = [self._resolve_table_fqn(t) for t in ex.get("tables", [])]
            table_fqns = [f for f in table_fqns if f]
            
            if not self.dry_run:
                self.kg.upsert_example(
                    ex["question"],
                    ex["sql"],
                    table_fqns,
                    ex.get("category", ""),
                )
            self.stats["examples"] += 1
        
        log.info(f"  {self.stats['examples']} examples created")
    
    def setup_vector_indexes(self):
        """Create vector search indexes."""
        if self.dry_run:
            log.info("Vector indexing: [DRY RUN] skipped")
            return
        
        log.info("Creating vector search indexes...")
        
        try:
            self.vs.create_indexes()
            log.info("  Vector indexes created/verified")
        except Exception as e:
            log.warning(f"  Vector index creation skipped: {e}")
    
    # ═══════════════════════════════════════════════════════════════════════
    # MAIN SETUP
    # ═══════════════════════════════════════════════════════════════════════
    
    def run(self):
        """Execute full semantic layer setup."""
        log.info("=" * 60)
        log.info("SEMANTIC LAYER SETUP (Configuration-Driven)")
        log.info("=" * 60)
        
        self.load_configs()
        
        self.setup_layer1_schema()
        self.setup_layer2_org_hierarchy()
        self.setup_layer3_kpis()
        self.setup_layer4_causal()
        self.setup_layer5_taxonomy()
        self.setup_domain_layers()
        self.setup_examples()
        self.setup_vector_indexes()
        
        log.info("=" * 60)
        log.info("SETUP COMPLETE")
        log.info("=" * 60)
        
        return self.stats


# ═══════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Configuration-driven semantic layer setup for Neo4j"
    )
    parser.add_argument(
        "--config-dir", "-c",
        default="configs/retail",
        help="Directory containing ontology.yaml and other config files"
    )
    parser.add_argument(
        "--dry-run", "-n",
        action="store_true",
        help="Validate configs without writing to Neo4j"
    )
    args = parser.parse_args()
    
    setup = ConfigurableSemanticLayerSetup(args.config_dir, args.dry_run)
    stats = setup.run()
    
    print("\n" + "=" * 40)
    print("STATISTICS")
    print("=" * 40)
    for key, value in stats.items():
        if value > 0:
            print(f"  {key}: {value}")


if __name__ == "__main__":
    main()